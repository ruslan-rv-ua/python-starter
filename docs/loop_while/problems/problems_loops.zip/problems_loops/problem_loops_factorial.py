'''
"Факторіал"

Реалізуйте функцію factorial(n) яка повертає факторіал натурального числа.
'''
def factorial(n):
	# ваш код
	
assert factorial(1) == 1
assert factorial(2) == 2
assert factorial(3) == 2 * 3
assert factorial(4) == 2 * 3 * 4
assert factorial(5) == 2 * 3 * 4 * 5
assert factorial(6) == 2 * 3 * 4 * 5 * 6
assert factorial(7) == 2 * 3 * 4 * 5 * 6 * 7