# -*- coding:UTF-8 -*-

from urllib.request import urlopen
from hashlib import md5
from time import sleep
from winsound import Beep
import os

REMOTE_FILE = 'http://ruslan.rv.ua/learn_code.py'
LOCAL_FILE = 'demo_code.py'

REFRESH_TIME = 3 # seconds
WAIT_AFTER_ERROR_TIME = 15 # seconds

MSG_UPDATED = 'Файл "{0}" оновлено.'
MSG_TIME = '\rОновлено {0} секунд тому '
MSG_ERROR = '\nПомилка: неможливо прочитати файл. Наступна спроба через {0} секунд.'


BEEPS_OK = ( (440,30), (880,30) )
BEEPS_ERROR = ( (1000,500), (1000,500), (1000,800))


clear = lambda: os.system('cls')

def NotifySound(beeps):
	for freq, dur in beeps:
		Beep(freq, dur)


last_md5 = ''
retrieves = 0


while True:
	try:
		with urlopen(REMOTE_FILE) as response:
			data = response.read()
			curr_md5 = md5(data).hexdigest()
			if curr_md5 != last_md5:
				last_md5 = curr_md5
				with open(LOCAL_FILE, 'wb') as file:
					file.write(data)
					clear()
					print(MSG_UPDATED.format(LOCAL_FILE))
					retrieves = 0
					NotifySound(BEEPS_OK)
			else:
				retrieves += 1
				print(MSG_TIME.format(retrieves*REFRESH_TIME), end = '', flush  = True)
			sleep(REFRESH_TIME)
	except:
		print(MSG_ERROR.format(WAIT_AFTER_ERROR_TIME))
		NotifySound(BEEPS_ERROR)
		sleep(WAIT_AFTER_ERROR_TIME)
		last_md5 = ''
		retrieves = 0


