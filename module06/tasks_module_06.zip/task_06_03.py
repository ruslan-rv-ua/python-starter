'''
Просте число -- це число, яке ділиться націло тільки на 1 і на себе.

Напишіть функцію is_prime() яка отримує натуральне число.
Функція повертає True, якщо передане їй число є простим, і False в іншому випадку.

Використовуючи написану функцію виведіть у стовпчик перші 7 простих чисел починаючи з числа 2.

Очікуваний вихід :
2
3
5
7
11
13
17
'''
def is_prime(n):
	for x in range(2,n):
		if(n % x==0):
			return False
	return True
	
number = 2
primes_count = 0
while primes_count < 7:
	if is_prime(number):
		print(number)
		primes_count += 1
	number += 1
